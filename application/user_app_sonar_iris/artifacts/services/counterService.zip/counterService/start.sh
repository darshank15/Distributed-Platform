python3 counterService.py $1 $2
