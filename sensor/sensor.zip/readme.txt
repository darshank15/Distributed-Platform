Run Commands:

### For starting Distance Sensor
python SimulateSensor.py localhost DISTANCE


### For starting Iris Sensor
python SimulateSensor.py localhost IRIS


### For starting SONAR Sensor
python SimulateSensor.py localhost SONAR
